from django.apps import AppConfig


class McConfig(AppConfig):
    name = 'MC'
